import java.io.*; // For handling file I/O
import java.util.*; // For using collections and utility classes

// Main class for the search engine
public class SimpleSearchEngine2 {

    // Map to store the original document content with IDs
    private Map<Integer, String> originalDocuments = new HashMap<>();
    // Map to store tokenized document content
    private Map<Integer, List<String>> documentIndex = new HashMap<>();
    // Inverted index for mapping words to document IDs
    private Map<String, List<Integer>> invertedIndex = new HashMap<>();
    // Set to store stopwords for filtering
    private Set<String> stopWords = new HashSet<>();

    // Method to load stopwords from a file
    public void loadStopWords(String filePath) {
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            // Read each line from the file and add to the stopWords set
            while ((line = br.readLine()) != null) {
                stopWords.add(line.trim().toLowerCase()); // Convert to lowercase to ensure consistency
            }
        } catch (IOException e) {
            e.printStackTrace(); // Print stack trace for any file reading issues
        }
    }

    // Method to read and process documents from a CSV file
    private void readDocuments(String filePath) {
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            int docId = 1; // Start document IDs from 1
            while ((line = br.readLine()) != null) {
                line = line.toLowerCase(); // Convert text to lowercase for uniformity
                line = line.replaceAll("[^a-zA-Z0-9\\s]", ""); // Remove punctuation using regex
                String[] words = line.split("\\s+"); // Split text by spaces into words
                List<String> processedWords = new ArrayList<>();
                for (String word : words) {
                    // Only add words that are not stopwords and not empty
                    if (!stopWords.contains(word) && !word.isEmpty()) {
                        processedWords.add(word);
                    }
                }
                originalDocuments.put(docId, line); // Store the original processed line
                documentIndex.put(docId, processedWords); // Store the tokenized words
                docId++; // Increment document ID for the next document
            }
        } catch (IOException e) {
            e.printStackTrace(); // Handle any file reading errors
        }
    }

    // Method to build the inverted index
    public void buildInvertedIndex() {
        // Loop through each document's word list
        for (Map.Entry<Integer, List<String>> entry : documentIndex.entrySet()) {
            int docId = entry.getKey(); // Current document ID
            List<String> words = entry.getValue(); // List of words in the document
            for (String word : words) {
                // If the word is not already in the index, create a new entry
                if (!invertedIndex.containsKey(word)) {
                    invertedIndex.put(word, new ArrayList<>());
                }
                // Add the document ID if not already present for this word
                if (!invertedIndex.get(word).contains(docId)) {
                    invertedIndex.get(word).add(docId);
                }
            }
        }
    }

    // Method to process Boolean queries (AND, OR)
    public Set<Integer> processBooleanQuery(String query) {
        String[] tokens = query.toLowerCase().split("\\s+"); // Split the query into terms
        Set<Integer> resultSet = new HashSet<>(); // Initialize the result set
        boolean isFirstTerm = true; // Flag to handle the first term's initialization
        String operator = ""; // To store the current Boolean operator

        for (String token : tokens) {
            if (token.equals("and") || token.equals("or")) {
                operator = token; // Set the operator if found in the query
            } else {
List<Integer> docList = invertedIndex.getOrDefault(token, new ArrayList<>()); // Get document list for the term
                Set<Integer> currentSet = new HashSet<>(docList); // Convert list to set for set operations

                if (isFirstTerm) {
                    resultSet = currentSet; // Initialize result set with the first term's documents
                    isFirstTerm = false; // Set flag to false after first term
                } else {
                    if (operator.equals("and")) {
                        resultSet.retainAll(currentSet); // Intersection for AND
                    } else if (operator.equals("or")) {
                        resultSet.addAll(currentSet); // Union for OR
                    }
                }
            }
        }
        return resultSet; // Return the final set of document IDs
    }

    // Method to calculate term frequency (TF) in a list of words
    private int calculateTermFrequency(List<String> words, String term) {
        int count = 0; // Initialize count
        for (String word : words) {
            if (word.equals(term)) {
                count++; // Increment count if the term matches
            }
        }
        return count; // Return the frequency count
    }

    // Method to rank documents based on term frequency for a query
    public List<Map.Entry<Integer, Integer>> rankDocuments(String query) {
        String[] queryTerms = query.toLowerCase().split("\\s+"); // Split query into terms
        Map<Integer, Integer> docScores = new HashMap<>(); // Map to store document ID and score

        // Loop through each document's word list
        for (Map.Entry<Integer, List<String>> entry : documentIndex.entrySet()) {
            int docId = entry.getKey(); // Current document ID
            List<String> words = entry.getValue(); // Words in the document
            int score = 0; // Initialize score for the document

            // Sum the term frequency for each query term in the document
            for (String term : queryTerms) {
                score += calculateTermFrequency(words, term);
            }

            if (score > 0) {
                docScores.put(docId, score); // Add document and its score to the map
            }
        }

        // Convert map entries to a list and sort by score in descending order
        List<Map.Entry<Integer, Integer>> sortedDocs = new ArrayList<>(docScores.entrySet());
        sortedDocs.sort((e1, e2) -> e2.getValue().compareTo(e1.getValue())); // Sort in descending order

        return sortedDocs; // Return the sorted list of document entries
    }

    // Main method for interactive testing
    public static void main(String[] args) {
        SimpleSearchEngine2 engine = new SimpleSearchEngine2();
        engine.loadStopWords("C://Users//user//Documents//stop.txt"); // Load stopwords from file
        engine.readDocuments("C://Users//user//Documents//dataset.csv"); // Read and process documents from CSV
        engine.buildInvertedIndex(); // Build the inverted index

        // Create a Scanner for user input
        Scanner scanner = new Scanner(System.in);

        // Loop to allow the user to enter search terms multiple times
        while (true) {
            System.out.println("\nEnter your search query (type 'exit' to quit):");
            String query = scanner.nextLine(); // Read user input

            // Exit the loop if the user types 'exit'
            if (query.equalsIgnoreCase("exit")) {
                System.out.println("Exiting the search engine. Goodbye!");
                break;
            }

            // Process the input for Boolean retrieval (AND/OR)
            System.out.println("\nBoolean Query Result:");
            Set<Integer> booleanResult = engine.processBooleanQuery(query);
            if (booleanResult.isEmpty()) {
                System.out.println("No documents found for your Boolean query.");
            } else {
                System.out.println("Documents found: " + booleanResult);
            }

            // Process the input for ranked retrieval
            System.out.
println("\nRanked Documents:");
            List<Map.Entry<Integer, Integer>> rankedDocs = engine.rankDocuments(query);
            if (rankedDocs.isEmpty()) {
                System.out.println("No documents found for ranking.");
            } else {
                for (Map.Entry<Integer, Integer> entry : rankedDocs) {
                    System.out.println("Doc ID: " + entry.getKey() + ", Score: " + entry.getValue());
                }
            }
        }

        scanner.close(); // Close the scanner when done
    }
}